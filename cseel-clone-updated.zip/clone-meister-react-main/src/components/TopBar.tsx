import { Link } from "react-router-dom";

const TopBar = () => {
  return (
    <div style={{ background: "hsl(211, 52%, 24%)" }} className="text-white text-sm">
      <div className="container mx-auto flex justify-end items-center py-2 px-4 gap-6">
        <Link to="/" className="hover:opacity-80 transition-opacity text-xs font-medium tracking-wide">Home</Link>
        <Link to="/contact-us" className="hover:opacity-80 transition-opacity text-xs font-medium tracking-wide">Get Support</Link>
        <Link to="/contact-us" className="hover:opacity-80 transition-opacity text-xs font-medium tracking-wide">Contact Us</Link>
        <Link to="/login" className="hover:opacity-80 transition-opacity text-xs font-medium tracking-wide">Login</Link>
      </div>
    </div>
  );
};

export default TopBar;
