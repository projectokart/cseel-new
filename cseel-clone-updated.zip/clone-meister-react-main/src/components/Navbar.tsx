import { Link } from "react-router-dom";
import { ChevronDown, Menu, X } from "lucide-react";
import { useState, useRef, useEffect } from "react";

const navItems = [
  {
    label: "Content Catalog",
    hasDropdown: true,
    sections: [
      {
        heading: "Simulations",
        items: [
          { label: "All Simulations", desc: "Browse hundreds of immersive science lab simulations.", to: "/simulations" },
          { label: "3D Chemistry Models", desc: "Learn key chemistry concepts with interactive 3D models.", to: "/demo" },
        ],
      },
      {
        heading: "Browse by",
        items: [
          { label: "Courses", desc: "Discover recommended simulations that align directly with your course's curriculum.", to: "/simulations" },
          { label: "Collections", desc: "Explore curated sets of interactive simulations designed to reinforce key concepts.", to: "/simulations" },
        ],
      },
      {
        heading: "VR for Nursing",
        items: [
          { label: "UbiSim by Cseel", desc: "Expand nurse training and institutional success through immersive VR simulations.", to: "/simulations" },
        ],
      },
      {
        heading: "Disciplines",
        items: [
          { label: "Biology", desc: "Transform results with virtual labs for biology courses.", to: "/demo?search=biology" },
          { label: "Chemistry", desc: "Discover Cseel's chemistry content designed to build confidence.", to: "/demo?search=chemistry" },
          { label: "Physics", desc: "Find relevant content with Cseel's curated physics simulations.", to: "/demo?search=physics" },
          { label: "Health Sciences", desc: "Help students understand complex concepts with virtual labs.", to: "/simulations" },
        ],
      },
    ],
    featured: {
      label: "Customer Story",
      title: "UNAB's Research Study Reveals Cseel's Power as a Pre-Lab Tool",
      desc: "UNAB study shows Cseel boosts student confidence, motivation, and learning.",
      to: "/about-us",
    },
  },
  {
    label: "Why Cseel",
    hasDropdown: true,
    sections: [
      {
        heading: "Our Solution",
        items: [
          { label: "Capabilities", desc: "Learn how cseel works and discover what's included with a subscription.", to: "/about-us" },
          { label: "Efficacy", desc: "See how cseel can take your STEM program to the next level.", to: "/about-us" },
        ],
      },
      {
        heading: "Getting Started",
        items: [
          { label: "Compare Plans", desc: "Find a plan that meets your academic needs.", to: "/compare-plans" },
          { label: "Partnerships", desc: "Join cseel and the industry's leading companies.", to: "/about-us" },
        ],
      },
    ],
    featured: {
      label: "Latest Research",
      title: "Reducing the gap in online student completion rates with a virtual lab",
      desc: "Study finds course completion rates improved by 16%.",
      to: "/about-us",
    },
  },
  {
    label: "Resources",
    hasDropdown: true,
    sections: [
      {
        heading: "Resources",
        items: [
          { label: "Blog", desc: "Stay up to date on helpful teaching resources and topics in STEM.", to: "#" },
          { label: "How to Guides", desc: "Browse student and educator guides and course collections.", to: "#" },
          { label: "Customer Stories", desc: "Learn how institutions like yours are using cseel.", to: "/about-us" },
          { label: "Research", desc: "Discover the research studies on cseel's efficacy and impact.", to: "/about-us" },
        ],
      },
    ],
    featured: {
      label: "Featured Article",
      title: "Interactive Lab Safety: How Virtual Labs Can Lead to Safer Physical Labs",
      desc: "Interactive lab safety training helps students build safe habits.",
      to: "/about-us",
    },
  },
  {
    label: "About Us",
    hasDropdown: true,
    sections: [
      {
        heading: "About Us",
        items: [
          { label: "About Cseel", desc: "Meet our leadership and read the story behind our immersive technology.", to: "/about-us" },
          { label: "In the News", desc: "Learn about our latest partnerships, achievements, and updates.", to: "/about-us" },
          { label: "Community", desc: "Connect with a community of educators and leaders.", to: "/about-us" },
          { label: "Careers", desc: "Join our team as we embark on empowering the world with knowledge.", to: "/about-us" },
        ],
      },
    ],
    featured: {
      label: "Recent News",
      title: "Cseel Strengthens Leadership Team with Distinguished Healthcare Experts",
      desc: "Cseel appoints new VP of Sales and Nursing Simulation Specialist.",
      to: "/about-us",
    },
  },
];

const Navbar = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [mobileExpanded, setMobileExpanded] = useState<string | null>(null);
  const [scrolled, setScrolled] = useState(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleMouseEnter = (label: string) => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    setOpenDropdown(label);
  };
  const handleMouseLeave = () => {
    timeoutRef.current = setTimeout(() => setOpenDropdown(null), 120);
  };

  return (
    <nav
      className="bg-white sticky top-0 z-50 transition-shadow duration-300"
      style={{ borderBottom: scrolled ? "1px solid hsl(214,32%,91%)" : "1px solid transparent", boxShadow: scrolled ? "0 1px 12px rgba(0,0,0,0.07)" : "none" }}
    >
      <div className="container mx-auto flex items-center justify-between px-4" style={{ height: "68px" }}>
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2.5 flex-shrink-0">
          <img src="/images/logo.png" alt="CSEEL Logo" className="h-9 w-9 object-contain" />
          <span className="text-lg font-bold tracking-wide" style={{ color: "hsl(219,72%,47%)" }}>C.S.E.E.L</span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-0.5">
          {navItems.map((item) => (
            <div
              key={item.label}
              className="relative"
              onMouseEnter={() => handleMouseEnter(item.label)}
              onMouseLeave={handleMouseLeave}
            >
              <button
                className="flex items-center gap-1 px-4 py-2 text-sm font-medium transition-colors rounded-md hover:bg-gray-50"
                style={{ color: openDropdown === item.label ? "hsl(219,72%,47%)" : "hsl(214,32%,18%)" }}
              >
                {item.label}
                <ChevronDown
                  className="h-3.5 w-3.5 transition-transform duration-200"
                  style={{ transform: openDropdown === item.label ? "rotate(180deg)" : "rotate(0deg)" }}
                />
              </button>

              {/* Mega dropdown */}
              {item.hasDropdown && openDropdown === item.label && (
                <div
                  className="absolute top-full left-1/2 bg-white rounded-2xl nav-dropdown z-50 overflow-hidden"
                  style={{
                    transform: "translateX(-50%)",
                    minWidth: "680px",
                    marginTop: "8px",
                    animation: "fadeSlideUp 0.18s ease forwards",
                    border: "1px solid hsl(214,32%,91%)",
                  }}
                  onMouseEnter={() => handleMouseEnter(item.label)}
                  onMouseLeave={handleMouseLeave}
                >
                  <div className="flex">
                    {/* Left: sections */}
                    <div className="flex-1 p-6 grid grid-cols-2 gap-x-8 gap-y-1">
                      {item.sections.map((section) => (
                        <div key={section.heading} className="mb-4">
                          <p className="text-xs font-semibold uppercase tracking-widest mb-2" style={{ color: "hsl(215,16%,47%)" }}>
                            {section.heading}
                          </p>
                          {section.items.map((child) => (
                            <Link
                              key={child.label}
                              to={child.to}
                              className="block px-2 py-1.5 rounded-lg hover:bg-blue-50 group transition-colors mb-0.5"
                              onClick={() => setOpenDropdown(null)}
                            >
                              <p className="text-sm font-medium group-hover:text-primary" style={{ color: "hsl(214,32%,18%)" }}>{child.label}</p>
                              <p className="text-xs mt-0.5 leading-tight" style={{ color: "hsl(215,16%,60%)" }}>{child.desc}</p>
                            </Link>
                          ))}
                        </div>
                      ))}
                    </div>
                    {/* Right: featured */}
                    {item.featured && (
                      <div className="w-56 p-6 flex-shrink-0" style={{ background: "hsl(219,72%,97%)", borderLeft: "1px solid hsl(219,72%,92%)" }}>
                        <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: "hsl(219,72%,47%)" }}>
                          {item.featured.label}
                        </p>
                        <Link
                          to={item.featured.to}
                          className="block group"
                          onClick={() => setOpenDropdown(null)}
                        >
                          <p className="text-sm font-semibold leading-snug mb-2 group-hover:text-primary transition-colors" style={{ color: "hsl(214,32%,18%)" }}>
                            {item.featured.title}
                          </p>
                          <p className="text-xs leading-relaxed" style={{ color: "hsl(215,16%,47%)" }}>{item.featured.desc}</p>
                          <p className="text-xs font-semibold mt-3 transition-colors" style={{ color: "hsl(219,72%,47%)" }}>
                            Read the story →
                          </p>
                        </Link>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* CTA Buttons */}
        <div className="hidden lg:flex items-center gap-3">
          <Link
            to="/contact-us"
            className="px-5 py-2 rounded-full text-sm font-semibold border-2 transition-all duration-200 hover:shadow-md"
            style={{ borderColor: "hsl(219,72%,47%)", color: "hsl(219,72%,47%)" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "hsl(219,72%,95%)"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}
          >
            Book A Demo
          </Link>
          <Link
            to="/compare-plans"
            className="px-5 py-2 rounded-full text-sm font-semibold text-white transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5"
            style={{ background: "hsl(219,72%,47%)" }}
            onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "hsl(219,72%,38%)"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "hsl(219,72%,47%)"; }}
          >
            Compare Plans
          </Link>
        </div>

        {/* Mobile toggle */}
        <button
          className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="lg:hidden border-t bg-white px-4 py-4 space-y-1 max-h-screen overflow-y-auto" style={{ borderColor: "hsl(214,32%,91%)" }}>
          {navItems.map((item) => (
            <div key={item.label}>
              <button
                className="w-full text-left px-3 py-2.5 text-sm font-medium rounded-lg hover:bg-gray-50 transition-colors"
                style={{ color: "hsl(214,32%,18%)" }}
                onClick={() => setMobileExpanded(mobileExpanded === item.label ? null : item.label)}
              >
                <span className="flex items-center justify-between">
                  {item.label}
                  <ChevronDown className={`h-4 w-4 transition-transform ${mobileExpanded === item.label ? "rotate-180" : ""}`} />
                </span>
              </button>
              {mobileExpanded === item.label && (
                <div className="pl-4 pb-2 space-y-0.5">
                  {item.sections.map((section) =>
                    section.items.map((child) => (
                      <Link
                        key={child.label}
                        to={child.to}
                        className="block px-3 py-2 text-sm rounded-lg hover:bg-blue-50 transition-colors"
                        style={{ color: "hsl(215,16%,47%)" }}
                        onClick={() => { setMobileOpen(false); setMobileExpanded(null); }}
                      >
                        {child.label}
                      </Link>
                    ))
                  )}
                </div>
              )}
            </div>
          ))}
          <div className="pt-3 space-y-2 border-t" style={{ borderColor: "hsl(214,32%,91%)" }}>
            <Link
              to="/contact-us"
              className="block text-center py-2.5 rounded-full text-sm font-semibold border-2 transition-colors"
              style={{ borderColor: "hsl(219,72%,47%)", color: "hsl(219,72%,47%)" }}
              onClick={() => setMobileOpen(false)}
            >
              Book A Demo
            </Link>
            <Link
              to="/compare-plans"
              className="block text-center py-2.5 rounded-full text-sm font-semibold text-white transition-colors"
              style={{ background: "hsl(219,72%,47%)" }}
              onClick={() => setMobileOpen(false)}
            >
              Compare Plans
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
