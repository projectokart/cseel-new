import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer style={{ background: "hsl(211, 52%, 24%)" }} className="text-white">
      <div className="container mx-auto px-4 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand */}
          <div className="lg:col-span-2">
            <Link to="/" className="flex items-center gap-3 mb-4">
              <img src="/images/logo.png" alt="CSEEL" className="h-9 w-9 object-contain brightness-200" />
              <span className="text-lg font-bold tracking-wide">C.S.E.E.L</span>
            </Link>
            <p className="text-sm leading-relaxed" style={{ color: "rgba(255,255,255,0.65)" }}>
              Center for Scientific Exploration and Experiential Learning. Transforming science education through hands-on, inquiry-based learning.
            </p>
            <div className="flex gap-4 mt-6">
              {["twitter", "linkedin", "youtube"].map((s) => (
                <a
                  key={s}
                  href="#"
                  className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-bold transition-all hover:opacity-80"
                  style={{ background: "rgba(255,255,255,0.12)" }}
                >
                  {s === "twitter" ? "𝕏" : s === "linkedin" ? "in" : "▶"}
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-sm mb-5 tracking-wide">Product</h4>
            <ul className="space-y-3 text-sm" style={{ color: "rgba(255,255,255,0.65)" }}>
              <li><Link to="/simulations" className="hover:text-white transition-colors">Simulations</Link></li>
              <li><Link to="/demo" className="hover:text-white transition-colors">Demo</Link></li>
              <li><Link to="/art" className="hover:text-white transition-colors">Science of Art</Link></li>
              <li><Link to="/compare-plans" className="hover:text-white transition-colors">Pricing</Link></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-semibold text-sm mb-5 tracking-wide">Company</h4>
            <ul className="space-y-3 text-sm" style={{ color: "rgba(255,255,255,0.65)" }}>
              <li><Link to="/about-us" className="hover:text-white transition-colors">About Us</Link></li>
              <li><Link to="/about-us" className="hover:text-white transition-colors">Careers</Link></li>
              <li><Link to="/about-us" className="hover:text-white transition-colors">In the News</Link></li>
              <li><Link to="/contact-us" className="hover:text-white transition-colors">Contact</Link></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-semibold text-sm mb-5 tracking-wide">Support</h4>
            <ul className="space-y-3 text-sm" style={{ color: "rgba(255,255,255,0.65)" }}>
              <li><Link to="/contact-us" className="hover:text-white transition-colors">Help Center</Link></li>
              <li><a href="mailto:support@cseel.org" className="hover:text-white transition-colors">support@cseel.org</a></li>
              <li><span>New Delhi, India</span></li>
            </ul>
            <div className="mt-6">
              <Link
                to="/compare-plans"
                className="inline-flex items-center px-5 py-2.5 rounded-full text-sm font-semibold text-white transition-all hover:opacity-90"
                style={{ background: "hsl(219,72%,47%)" }}
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>

        <div
          className="mt-12 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs"
          style={{ borderTop: "1px solid rgba(255,255,255,0.12)", color: "rgba(255,255,255,0.45)" }}
        >
          <p>© {new Date().getFullYear()} CSEEL. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-white transition-colors">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
