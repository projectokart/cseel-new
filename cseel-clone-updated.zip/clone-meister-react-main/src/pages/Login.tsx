import { Link } from "react-router-dom";
import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Login functionality requires backend integration.");
  };

  return (
    <div className="min-h-screen flex" style={{ fontFamily: "'DM Sans', sans-serif" }}>
      {/* Left - Brand Panel */}
      <div className="hidden lg:flex flex-1 items-center justify-center" style={{ background: "linear-gradient(135deg, hsl(211,52%,24%) 0%, hsl(219,72%,40%) 100%)" }}>
        <div className="text-center px-8">
          <Link to="/" className="flex items-center justify-center gap-4 mb-6">
            <img src="/images/logo.png" alt="CSEEL" className="h-14 w-14 object-contain brightness-200" />
            <span className="text-3xl font-bold text-white tracking-wide">C.S.E.E.L</span>
          </Link>
          <p className="text-white/70 text-sm max-w-xs leading-relaxed">
            Center for Scientific Exploration and Experiential Learning. Empowering students through hands-on science.
          </p>
        </div>
      </div>

      {/* Right - Login Form */}
      <div className="flex-1 flex items-center justify-center p-8 bg-white">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <Link to="/" className="flex items-center gap-3 mb-8 lg:hidden">
            <img src="/images/logo.png" alt="CSEEL" className="h-8 w-8 object-contain" />
            <span className="text-lg font-bold" style={{ color: "hsl(219,72%,47%)" }}>C.S.E.E.L</span>
          </Link>

          <h1 className="text-2xl font-bold mb-1" style={{ color: "hsl(214,32%,18%)", letterSpacing: "-0.02em" }}>Welcome back</h1>
          <p className="text-sm mb-8" style={{ color: "hsl(215,16%,47%)" }}>Log in to your CSEEL account</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-xs font-semibold uppercase tracking-wide mb-1.5 block" style={{ color: "hsl(214,32%,18%)" }}>Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@institution.edu"
                className="w-full px-4 py-3 rounded-xl text-sm outline-none transition-all"
                style={{ border: "1.5px solid hsl(214,32%,85%)", color: "hsl(214,32%,18%)" }}
                onFocus={e => { (e.target as HTMLElement).style.borderColor = "hsl(219,72%,47%)"; (e.target as HTMLElement).style.boxShadow = "0 0 0 3px hsl(219,72%,95%)"; }}
                onBlur={e => { (e.target as HTMLElement).style.borderColor = "hsl(214,32%,85%)"; (e.target as HTMLElement).style.boxShadow = "none"; }}
                required
              />
            </div>
            <div>
              <label className="text-xs font-semibold uppercase tracking-wide mb-1.5 block" style={{ color: "hsl(214,32%,18%)" }}>Password</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 rounded-xl text-sm outline-none transition-all pr-11"
                  style={{ border: "1.5px solid hsl(214,32%,85%)", color: "hsl(214,32%,18%)" }}
                  onFocus={e => { (e.target as HTMLElement).style.borderColor = "hsl(219,72%,47%)"; (e.target as HTMLElement).style.boxShadow = "0 0 0 3px hsl(219,72%,95%)"; }}
                  onBlur={e => { (e.target as HTMLElement).style.borderColor = "hsl(214,32%,85%)"; (e.target as HTMLElement).style.boxShadow = "none"; }}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 transition-colors hover:opacity-70"
                  style={{ color: "hsl(215,16%,47%)" }}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="flex justify-end">
              <Link to="#" className="text-xs font-medium hover:underline" style={{ color: "hsl(219,72%,47%)" }}>Forgot password?</Link>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl text-sm font-semibold text-white transition-all duration-200 hover:opacity-90 hover:-translate-y-0.5 hover:shadow-lg"
              style={{ background: "hsl(219,72%,47%)" }}
            >
              Log In
            </button>
          </form>

          <div className="flex items-center my-6">
            <div className="flex-1 h-px" style={{ background: "hsl(214,32%,91%)" }} />
            <span className="px-4 text-xs" style={{ color: "hsl(215,16%,60%)" }}>or continue with</span>
            <div className="flex-1 h-px" style={{ background: "hsl(214,32%,91%)" }} />
          </div>

          <div className="space-y-3">
            <button
              className="w-full flex items-center justify-center gap-3 py-3 rounded-xl text-sm font-medium transition-all hover:-translate-y-0.5 hover:shadow-sm"
              style={{ border: "1.5px solid hsl(214,32%,91%)", color: "hsl(214,32%,18%)" }}
            >
              <img src="https://www.gstatic.com/images/branding/product/2x/classroom_48dp.png" alt="Google Classroom" className="h-5 w-5" />
              Log in with Google Classroom
            </button>
            <Link
              to="#"
              className="w-full flex items-center justify-center py-3 rounded-xl text-sm font-medium transition-all hover:-translate-y-0.5 hover:shadow-sm"
              style={{ border: "1.5px solid hsl(219,72%,47%)", color: "hsl(219,72%,47%)" }}
            >
              Sign up with a Course Code
            </Link>
          </div>

          <p className="text-center text-xs mt-6" style={{ color: "hsl(215,16%,60%)" }}>
            Having trouble?{" "}
            <Link to="/contact-us" className="font-medium hover:underline" style={{ color: "hsl(219,72%,47%)" }}>Cseel Help Center</Link>
          </p>
          <p className="text-center text-xs mt-2" style={{ color: "hsl(215,16%,65%)" }}>
            You can log in, but playing simulations is currently not supported on mobile devices.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
