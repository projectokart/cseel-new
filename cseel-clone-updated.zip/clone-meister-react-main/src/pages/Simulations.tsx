import Layout from "@/components/Layout";
import { Link } from "react-router-dom";
import { useState } from "react";
import { Search } from "lucide-react";

const disciplines = ["All", "Chemistry", "Biology", "Physics", "Engineering", "Technology", "Mathematics"];

const simulations = [
  { title: "Absorption In the Small and Large Intestines", discipline: "Biology", level: "Higher Education", image: "https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66bf9f93d712be6d135ac575_Student-Remote-Room-Labster-reverse-edit.avif" },
  { title: "Acid-Base Titration", discipline: "Chemistry", level: "Higher Education", image: "https://img.freepik.com/premium-photo/chemistryfilled-beakers-beakers-with-colorful-chemical-generative-ai_722401-1517.jpg" },
  { title: "Newton's Laws of Motion", discipline: "Physics", level: "High School", image: "https://img.freepik.com/premium-photo/physics-lab-background-with-pendulums-circuits_641503-120945.jpg" },
  { title: "Cell Structure and Function", discipline: "Biology", level: "High School", image: "https://png.pngtree.com/thumb_back/fw800/background/20241007/pngtree-biology-laboratory-nature-and-science-plants-with-biochemistry-structure-on-green-image_16319180.jpg" },
  { title: "Electrochemistry Fundamentals", discipline: "Chemistry", level: "Higher Education", image: "https://img.freepik.com/premium-photo/chemistryfilled-beakers-beakers-with-colorful-chemical-generative-ai_722401-1517.jpg" },
  { title: "Circuit Design Basics", discipline: "Engineering", level: "Higher Education", image: "https://img.freepik.com/premium-photo/technology-abstract-circuit-board-texture-background-hightech-futuristic-circuit-board-banner-wallpaper_1029473-136066.jpg" },
  { title: "DNA Extraction Lab", discipline: "Biology", level: "Higher Education", image: "https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66bf944f3df098f183b92727_Lab-Scientists-Beakers-edit.avif" },
  { title: "Thermodynamics Exploration", discipline: "Physics", level: "Higher Education", image: "https://img.freepik.com/premium-photo/physics-lab-background-with-pendulums-circuits_641503-120945.jpg" },
  { title: "Genetic Inheritance Lab", discipline: "Biology", level: "Higher Education", image: "https://png.pngtree.com/thumb_back/fw800/background/20241007/pngtree-biology-laboratory-nature-and-science-plants-with-biochemistry-structure-on-green-image_16319180.jpg" },
  { title: "Organic Chemistry Reactions", discipline: "Chemistry", level: "Higher Education", image: "https://img.freepik.com/premium-photo/chemistryfilled-beakers-beakers-with-colorful-chemical-generative-ai_722401-1517.jpg" },
];

const Simulations = () => {
  const [search, setSearch] = useState("");
  const [level, setLevel] = useState("Higher Education");
  const [discipline, setDiscipline] = useState("All");

  const filtered = simulations.filter((s) => {
    const matchSearch = s.title.toLowerCase().includes(search.toLowerCase());
    const matchLevel = s.level === level;
    const matchDiscipline = discipline === "All" || s.discipline === discipline;
    return matchSearch && matchLevel && matchDiscipline;
  });

  return (
    <Layout>
      {/* Hero */}
      <section className="about-hero-gradient py-16">
        <div className="container mx-auto px-4" style={{ animation: "fadeSlideUp 0.7s ease forwards" }}>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: "rgba(255,255,255,0.6)" }}>Content Catalog</p>
              <h1 className="text-3xl md:text-4xl font-bold text-white mb-4" style={{ letterSpacing: "-0.03em" }}>Browse our Catalog</h1>
              <p className="text-sm mb-6" style={{ color: "rgba(255,255,255,0.75)" }}>Take a look through our 1000+ virtual lab simulation options and find the content you need.</p>
              <Link to="/compare-plans" className="inline-flex items-center px-6 py-2.5 bg-white rounded-full text-sm font-semibold transition-all hover:shadow-lg hover:-translate-y-0.5" style={{ color: "hsl(219,72%,47%)" }}>
                See Pricing & Plans
              </Link>
            </div>
            <div className="space-y-5">
              {[{ icon: "📚", title: "Catalog Access", desc: "Every subscription includes access to choose virtual lab simulations that best fit your curriculum." }, { icon: "🗺️", title: "Course Mapping", desc: "Our Advanced and Elite plans include a dedicated Customer Success Manager to match course syllabi to relevant simulations." }].map((f) => (
                <div key={f.title} className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 text-lg" style={{ background: "rgba(255,255,255,0.15)" }}>{f.icon}</div>
                  <div>
                    <h3 className="font-semibold text-sm text-white mb-1">{f.title}</h3>
                    <p className="text-xs leading-relaxed" style={{ color: "rgba(255,255,255,0.65)" }}>{f.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8" style={{ background: "#fff" }}>
        <div className="container mx-auto px-4">
          <div className="rounded-2xl p-6" style={{ border: "1px solid hsl(214,32%,91%)", background: "hsl(219,72%,98%)" }}>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="text-xs font-semibold uppercase tracking-wide mb-2 block" style={{ color: "hsl(219,72%,47%)" }}>Search</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4" style={{ color: "hsl(215,16%,60%)" }} />
                  <input type="text" placeholder="Search simulations..." value={search} onChange={(e) => setSearch(e.target.value)}
                    className="w-full pl-9 pr-4 py-2.5 rounded-xl text-sm outline-none" style={{ border: "1.5px solid hsl(214,32%,85%)" }} />
                </div>
                <p className="text-xs mt-1.5" style={{ color: "hsl(215,16%,60%)" }}>{filtered.length} results</p>
              </div>
              <div>
                <label className="text-xs font-semibold uppercase tracking-wide mb-2 block" style={{ color: "hsl(219,72%,47%)" }}>Level</label>
                <div className="flex rounded-xl overflow-hidden" style={{ border: "1.5px solid hsl(214,32%,85%)" }}>
                  {["Higher Education", "High School"].map((l) => (
                    <button key={l} onClick={() => setLevel(l)} className="flex-1 px-4 py-2.5 text-xs font-semibold transition-colors"
                      style={{ background: level === l ? "hsl(219,72%,47%)" : "white", color: level === l ? "white" : "hsl(214,32%,18%)" }}>
                      {l}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-xs font-semibold uppercase tracking-wide mb-2 block" style={{ color: "hsl(219,72%,47%)" }}>Discipline</label>
                <select value={discipline} onChange={(e) => setDiscipline(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl text-sm outline-none" style={{ border: "1.5px solid hsl(214,32%,85%)", background: "white" }}>
                  {disciplines.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Results */}
      <section className="py-6 pb-16" style={{ background: "#fff" }}>
        <div className="container mx-auto px-4">
          <div className="space-y-3">
            {filtered.map((sim, i) => (
              <div key={i} className="flex gap-5 rounded-2xl p-4 transition-all hover:shadow-md hover:-translate-y-0.5" style={{ border: "1px solid hsl(214,32%,91%)" }}>
                <img src={sim.image} alt={sim.title} className="w-40 h-28 object-cover rounded-xl flex-shrink-0 hidden md:block" />
                <div className="flex flex-col justify-center">
                  <h3 className="text-base font-bold mb-1 hover:underline cursor-pointer" style={{ color: "hsl(219,72%,47%)" }}>{sim.title}</h3>
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2.5 py-1 rounded-full font-medium" style={{ background: "hsl(219,72%,95%)", color: "hsl(219,72%,47%)" }}>{sim.discipline}</span>
                    <span className="text-xs" style={{ color: "hsl(215,16%,60%)" }}>{sim.level}</span>
                  </div>
                </div>
              </div>
            ))}
            {filtered.length === 0 && (
              <div className="text-center py-20">
                <p className="text-sm" style={{ color: "hsl(215,16%,60%)" }}>No simulations found matching your criteria.</p>
              </div>
            )}
          </div>
        </div>
      </section>
    </Layout>
  );
};
export default Simulations;
