import Layout from "@/components/Layout";
import { Link } from "react-router-dom";
import { useState } from "react";
import { Search } from "lucide-react";

const activities = [
  { name: "Acid-Base Titration", subject: "Chemistry", image: "https://img.freepik.com/premium-photo/chemistryfilled-beakers-beakers-with-colorful-chemical-generative-ai_722401-1517.jpg" },
  { name: "Newton's Second Law", subject: "Physics", image: "https://img.freepik.com/premium-photo/physics-lab-background-with-pendulums-circuits_641503-120945.jpg" },
  { name: "Cell Division - Mitosis", subject: "Biology", image: "https://png.pngtree.com/thumb_back/fw800/background/20241007/pngtree-biology-laboratory-nature-and-science-plants-with-biochemistry-structure-on-green-image_16319180.jpg" },
  { name: "Electrochemistry", subject: "Chemistry", image: "https://img.freepik.com/premium-photo/chemistryfilled-beakers-beakers-with-colorful-chemical-generative-ai_722401-1517.jpg" },
  { name: "Projectile Motion", subject: "Physics", image: "https://img.freepik.com/premium-photo/physics-lab-background-with-pendulums-circuits_641503-120945.jpg" },
  { name: "DNA Extraction", subject: "Biology", image: "https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66bf944f3df098f183b92727_Lab-Scientists-Beakers-edit.avif" },
  { name: "Chemical Bonding", subject: "Chemistry", image: "https://img.freepik.com/premium-photo/chemistryfilled-beakers-beakers-with-colorful-chemical-generative-ai_722401-1517.jpg" },
  { name: "Pendulum Lab", subject: "Physics", image: "https://img.freepik.com/premium-photo/physics-lab-background-with-pendulums-circuits_641503-120945.jpg" },
  { name: "Photosynthesis Lab", subject: "Biology", image: "https://png.pngtree.com/thumb_back/fw800/background/20241007/pngtree-biology-laboratory-nature-and-science-plants-with-biochemistry-structure-on-green-image_16319180.jpg" },
];

const Demo = () => {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const [selected, setSelected] = useState<string[]>([]);
  const [showSelection, setShowSelection] = useState(false);

  const filtered = activities.filter((a) => {
    const matchSearch = a.name.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === "All" || a.subject === filter;
    return matchSearch && matchFilter;
  });

  const toggleSelect = (name: string) => {
    setSelected((prev) =>
      prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name]
    );
  };

  const physCount = selected.filter((n) => activities.find((a) => a.name === n)?.subject === "Physics").length;
  const chemCount = selected.filter((n) => activities.find((a) => a.name === n)?.subject === "Chemistry").length;
  const bioCount = selected.filter((n) => activities.find((a) => a.name === n)?.subject === "Biology").length;

  return (
    <Layout>
      {/* Hero */}
      <section className="about-hero-gradient py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-sm font-semibold text-primary-foreground/70 mb-2">Browse our Catalog</p>
              <h1 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">Browse our Catalog</h1>
              <p className="text-primary-foreground/80 mb-6">
                Take a look through our 300+ virtual labs simulation options and find the content you need.
              </p>
              <Link
                to="/compare-plans"
                className="inline-flex items-center px-6 py-2.5 bg-background text-primary font-semibold rounded-full hover:bg-primary-light transition-colors"
              >
                See Pricing & Plans
              </Link>
            </div>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-primary-foreground/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-primary-foreground text-lg">📚</span>
                </div>
                <div>
                  <h3 className="font-semibold text-primary-foreground">Catalog Access</h3>
                  <p className="text-sm text-primary-foreground/70">Every subscription includes access to choose virtual lab simulations that best fit your curriculum.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-primary-foreground/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-primary-foreground text-lg">🗺️</span>
                </div>
                <div>
                  <h3 className="font-semibold text-primary-foreground">Course Mapping</h3>
                  <p className="text-sm text-primary-foreground/70">Our Advanced and Elite plans include a dedicated Customer Success Manager to match course syllabi to relevant experiments.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="bg-background border-b border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-6 divide-x divide-border text-center py-3">
            <div>
              <div className="text-lg font-bold text-primary">{filtered.length}</div>
              <div className="text-xs text-muted-foreground">TOTAL</div>
            </div>
            <div>
              <div className="text-lg font-bold text-primary">0</div>
              <div className="text-xs text-muted-foreground">SCROLLED</div>
            </div>
            <div>
              <div className="text-lg font-bold text-primary bg-primary/10 rounded-full inline-block px-3">{selected.length}</div>
              <div className="text-xs text-muted-foreground">SELECTED</div>
            </div>
            <div>
              <div className="text-lg font-bold text-primary">{physCount}</div>
              <div className="text-xs text-muted-foreground">PHY.</div>
            </div>
            <div>
              <div className="text-lg font-bold text-primary">{chemCount}</div>
              <div className="text-xs text-muted-foreground">CHEM</div>
            </div>
            <div>
              <div className="text-lg font-bold text-primary">{bioCount}</div>
              <div className="text-xs text-muted-foreground">BIO</div>
            </div>
          </div>
        </div>
      </section>

      {/* Search & Filter */}
      <section className="py-6 bg-background">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-center mb-6">
            <div className="relative flex-1 max-w-xl">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                type="text"
                placeholder="Search activities..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 border border-input rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
            <button
              onClick={() => setShowSelection(!showSelection)}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-full text-sm font-semibold"
            >
              Selection List
            </button>
          </div>
          <div className="flex gap-2 justify-center flex-wrap">
            {["All", "Physics", "Chemistry", "Biology"].map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-4 py-1.5 rounded-full text-sm font-medium border transition-colors ${
                  filter === f
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-background text-foreground border-border hover:border-primary"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Selection Modal */}
      {showSelection && (
        <div className="fixed inset-0 bg-foreground/50 z-50 flex items-center justify-center p-4">
          <div className="bg-background rounded-xl p-6 max-w-lg w-full max-h-[70vh] overflow-auto shadow-xl">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-foreground">Selected Activities</h3>
              <button onClick={() => setShowSelection(false)} className="text-muted-foreground hover:text-foreground text-xl">×</button>
            </div>
            {selected.length === 0 ? (
              <p className="text-muted-foreground text-sm">No activities selected yet.</p>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-2 text-foreground">#</th>
                    <th className="text-left py-2 text-foreground">Activity Name</th>
                    <th className="text-left py-2 text-foreground">Subject</th>
                    <th className="text-right py-2 text-foreground">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {selected.map((name, i) => {
                    const act = activities.find((a) => a.name === name);
                    return (
                      <tr key={name} className="border-b border-border">
                        <td className="py-2 text-muted-foreground">{i + 1}</td>
                        <td className="py-2 text-foreground">{name}</td>
                        <td className="py-2 text-muted-foreground">{act?.subject}</td>
                        <td className="py-2 text-right">
                          <button onClick={() => toggleSelect(name)} className="text-destructive text-xs">Remove</button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
            <button
              onClick={() => { alert("Request submitted!"); setShowSelection(false); }}
              className="mt-4 w-full py-2.5 bg-primary text-primary-foreground rounded-full font-semibold text-sm"
            >
              Submit Request
            </button>
          </div>
        </div>
      )}

      {/* Activity Cards */}
      <section className="py-8 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((activity) => (
              <div
                key={activity.name}
                onClick={() => toggleSelect(activity.name)}
                className={`cursor-pointer rounded-xl overflow-hidden border transition-all hover:shadow-lg ${
                  selected.includes(activity.name) ? "border-primary ring-2 ring-primary/30" : "border-border"
                }`}
              >
                <img src={activity.image} alt={activity.name} className="w-full h-40 object-cover" />
                <div className="p-4">
                  <h3 className="font-semibold text-foreground">{activity.name}</h3>
                  <p className="text-sm text-muted-foreground">{activity.subject}</p>
                  {selected.includes(activity.name) && (
                    <span className="inline-block mt-2 text-xs bg-primary/10 text-primary px-2 py-1 rounded-full">✓ Selected</span>
                  )}
                </div>
              </div>
            ))}
          </div>
          {filtered.length === 0 && (
            <p className="text-center text-muted-foreground py-12">No activities found.</p>
          )}
        </div>
      </section>
    </Layout>
  );
};

export default Demo;
