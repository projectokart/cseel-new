import Layout from "@/components/Layout";
import { useState } from "react";

const ContactUs = () => {
  const [formData, setFormData] = useState({ firstName: "", lastName: "", email: "", institution: "", phone: "", position: "", type: "", country: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 4000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const inputClass = "w-full px-3.5 py-2.5 rounded-xl text-sm outline-none transition-all";
  const inputStyle = { border: "1.5px solid hsl(214,32%,85%)", color: "hsl(214,32%,18%)", fontFamily: "'DM Sans', sans-serif" };
  const focusHandler = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    (e.target as HTMLElement).style.borderColor = "hsl(219,72%,47%)";
    (e.target as HTMLElement).style.boxShadow = "0 0 0 3px hsl(219,72%,95%)";
  };
  const blurHandler = (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    (e.target as HTMLElement).style.borderColor = "hsl(214,32%,85%)";
    (e.target as HTMLElement).style.boxShadow = "none";
  };
  const labelClass = "text-xs font-semibold uppercase tracking-wide mb-1.5 block";
  const labelStyle = { color: "hsl(214,32%,18%)" };

  return (
    <Layout>
      {/* Hero */}
      <section className="hero-gradient py-14">
        <div className="container mx-auto px-4" style={{ animation: "fadeSlideUp 0.7s ease forwards" }}>
          <h1 className="text-3xl md:text-4xl font-bold mb-2" style={{ color: "hsl(219,72%,47%)", letterSpacing: "-0.03em" }}>Contact Us</h1>
          <p className="text-sm" style={{ color: "hsl(215,16%,47%)" }}>Need to reach our team? Let us know you need help and we will be in touch.</p>
        </div>
      </section>

      <section className="py-14" style={{ background: "#fff" }}>
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-14">
            {/* Left */}
            <div>
              <div className="mb-8">
                <h3 className="text-base font-bold mb-2" style={{ color: "hsl(219,72%,47%)" }}>New Delhi</h3>
                <p className="text-sm leading-relaxed" style={{ color: "hsl(215,16%,47%)" }}>
                  Mr. Dev Sharma<br />
                  9050778830<br />
                  New Delhi-110001<br />
                  India
                </p>
              </div>
              <div className="grid grid-cols-2 gap-8 mb-8">
                <div>
                  <h3 className="text-base font-bold mb-2" style={{ color: "hsl(219,72%,47%)" }}>Customer Support</h3>
                  <a href="mailto:support@cseel.org" className="text-sm hover:underline" style={{ color: "hsl(215,16%,47%)" }}>support@cseel.org</a>
                </div>
                <div>
                  <h3 className="text-base font-bold mb-2" style={{ color: "hsl(219,72%,47%)" }}>Help Center</h3>
                  <a href="https://help.cseel.org" className="text-sm hover:underline" style={{ color: "hsl(215,16%,47%)" }}>help.cseel.org</a>
                </div>
              </div>
              <div className="rounded-2xl overflow-hidden shadow-lg">
                <img src="https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66bf9f93d712be6d135ac575_Student-Remote-Room-Labster-reverse-edit.avif" alt="Student using tablet" className="w-full h-64 object-cover" />
              </div>
            </div>

            {/* Right - Form */}
            <div className="bg-white rounded-2xl p-8" style={{ border: "1px solid hsl(214,32%,91%)", boxShadow: "0 4px 24px rgba(0,0,0,0.06)" }}>
              <h2 className="text-base font-bold mb-6" style={{ color: "hsl(214,32%,18%)" }}>Fill out the form and we'll be in touch.</h2>
              {submitted && (
                <div className="mb-4 px-4 py-3 rounded-xl text-sm font-medium" style={{ background: "hsl(142,72%,95%)", color: "hsl(142,72%,30%)", border: "1px solid hsl(142,72%,80%)" }}>
                  ✓ Thank you! We'll be in touch soon.
                </div>
              )}
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className={labelClass} style={labelStyle}><span style={{ color: "hsl(0,84%,60%)" }}>*</span> First Name</label>
                    <input name="firstName" value={formData.firstName} onChange={handleChange} placeholder="First Name" required className={inputClass} style={inputStyle} onFocus={focusHandler} onBlur={blurHandler} />
                  </div>
                  <div>
                    <label className={labelClass} style={labelStyle}><span style={{ color: "hsl(0,84%,60%)" }}>*</span> Last Name</label>
                    <input name="lastName" value={formData.lastName} onChange={handleChange} placeholder="Last Name" required className={inputClass} style={inputStyle} onFocus={focusHandler} onBlur={blurHandler} />
                  </div>
                </div>
                <div>
                  <label className={labelClass} style={labelStyle}><span style={{ color: "hsl(0,84%,60%)" }}>*</span> Email</label>
                  <input name="email" type="email" value={formData.email} onChange={handleChange} placeholder="you@institution.edu" required className={inputClass} style={inputStyle} onFocus={focusHandler} onBlur={blurHandler} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className={labelClass} style={labelStyle}><span style={{ color: "hsl(0,84%,60%)" }}>*</span> Institution</label>
                    <input name="institution" value={formData.institution} onChange={handleChange} placeholder="Institution Name" required className={inputClass} style={inputStyle} onFocus={focusHandler} onBlur={blurHandler} />
                  </div>
                  <div>
                    <label className={labelClass} style={labelStyle}><span style={{ color: "hsl(0,84%,60%)" }}>*</span> Phone</label>
                    <input name="phone" value={formData.phone} onChange={handleChange} placeholder="+91 98765 43210" required className={inputClass} style={inputStyle} onFocus={focusHandler} onBlur={blurHandler} />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className={labelClass} style={labelStyle}><span style={{ color: "hsl(0,84%,60%)" }}>*</span> Position</label>
                    <select name="position" value={formData.position} onChange={handleChange} required className={inputClass} style={{ ...inputStyle, background: "white" }} onFocus={focusHandler} onBlur={blurHandler}>
                      <option value="">Select...</option>
                      <option>Professor</option><option>Teacher</option><option>Administrator</option><option>Student</option><option>Other</option>
                    </select>
                  </div>
                  <div>
                    <label className={labelClass} style={labelStyle}><span style={{ color: "hsl(0,84%,60%)" }}>*</span> Type</label>
                    <select name="type" value={formData.type} onChange={handleChange} required className={inputClass} style={{ ...inputStyle, background: "white" }} onFocus={focusHandler} onBlur={blurHandler}>
                      <option value="">Select...</option>
                      <option>University</option><option>School</option><option>College</option><option>Other</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className={labelClass} style={labelStyle}><span style={{ color: "hsl(0,84%,60%)" }}>*</span> Country</label>
                  <select name="country" value={formData.country} onChange={handleChange} required className={inputClass} style={{ ...inputStyle, background: "white" }} onFocus={focusHandler} onBlur={blurHandler}>
                    <option value="">Select country...</option>
                    <option>India</option><option>USA</option><option>UK</option><option>Canada</option><option>Other</option>
                  </select>
                </div>
                <div>
                  <label className={labelClass} style={labelStyle}><span style={{ color: "hsl(0,84%,60%)" }}>*</span> Message</label>
                  <textarea name="message" value={formData.message} onChange={handleChange} placeholder="How can we help you?" rows={4} required className={inputClass + " resize-none"} style={inputStyle} onFocus={focusHandler as any} onBlur={blurHandler as any} />
                </div>
                <button type="submit" className="w-full py-3 rounded-xl text-sm font-semibold text-white transition-all duration-200 hover:opacity-90 hover:-translate-y-0.5 hover:shadow-lg" style={{ background: "hsl(219,72%,47%)" }}>
                  Submit
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};
export default ContactUs;
