import Layout from "@/components/Layout";
import { Link } from "react-router-dom";

const artItems = [
  {
    title: "The Power of Music",
    description: "Music heals, inspires, and unites people by expressing emotions beyond words. It transcends language, connects hearts, and turns moments into memories. Whether joyful or sorrowful, music gives voice to feelings we often can't explain.",
    duration: "22 Min",
    category: "Sciences of Art",
    level: "High School",
    videoId: "YRJ6xoiRcpQ",
  },
];

const Art = () => {
  return (
    <Layout>
      {/* Hero */}
      <section className="about-hero-gradient py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">Science of Art</h1>
              <p className="text-primary-foreground/80 mb-6 leading-relaxed">
                The science of art reveals the hidden logic behind creativity. From the geometry in design to the physics of light and sound, every artistic expression is rooted in scientific principles. Whether it's the chemistry of pigments, the neuroscience of perception, or the math behind music and patterns, art and science work together to help us understand and shape the world in beautiful ways.
              </p>
              <Link
                to="/compare-plans"
                className="inline-flex items-center px-6 py-2.5 bg-background text-primary font-semibold rounded-full hover:bg-primary-light transition-colors"
              >
                See Pricing & Plans
              </Link>
            </div>
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-primary-foreground/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-primary-foreground text-lg">📚</span>
                </div>
                <div>
                  <h3 className="font-semibold text-primary-foreground">Catalog Access</h3>
                  <p className="text-sm text-primary-foreground/70">Every subscription includes access to choose virtual lab simulations that best fit your curriculum.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-full bg-primary-foreground/20 flex items-center justify-center flex-shrink-0">
                  <span className="text-primary-foreground text-lg">🗺️</span>
                </div>
                <div>
                  <h3 className="font-semibold text-primary-foreground">Course Mapping</h3>
                  <p className="text-sm text-primary-foreground/70">Our Advanced and Elite plans include a dedicated Customer Success Manager to match course syllabi to relevant simulations.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Art Content */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {artItems.map((item) => (
              <div key={item.title} className="rounded-xl border border-border overflow-hidden shadow-sm hover:shadow-lg transition-shadow">
                <div className="relative aspect-video">
                  <iframe
                    src={`https://www.youtube.com/embed/${item.videoId}`}
                    title={item.title}
                    className="w-full h-full"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </div>
                <div className="p-5">
                  <Link to="/simulations" className="text-lg font-bold text-primary hover:underline">
                    {item.title}
                  </Link>
                  <p className="text-sm text-muted-foreground mt-2">{item.description}</p>
                  <div className="flex items-center gap-3 mt-4">
                    <span className="text-xs bg-primary-light text-primary px-2 py-1 rounded-full font-medium">{item.duration}</span>
                    <span className="text-xs bg-primary-light text-primary px-2 py-1 rounded-full font-medium">{item.category}</span>
                    <span className="text-xs bg-primary-light text-primary px-2 py-1 rounded-full font-medium">{item.level}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Art;
