import Layout from "@/components/Layout";
import { Link } from "react-router-dom";
import { CheckCircle } from "lucide-react";
import { useEffect, useRef, useState } from "react";

function useScrollReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setVisible(true); obs.unobserve(el); } }, { threshold: 0.1 });
    obs.observe(el); return () => obs.disconnect();
  }, []);
  return { ref, visible };
}

const testimonials = [
  { name: "Rakesh Sharma", title: "Associate Professor, Delhi University", image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQasrbD4o8y03QK0ogqw8jJtrRMkApA8HLtDw&s", quote: "My goal is for students to have experiences that simulate the hands-on labs they would encounter if they were in person. Cseel is the most hands-on experience students can get without stepping into a lab." },
  { name: "Vivek Sharma", title: "Korean Embassy", image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQihhZf7her-3KOsNQwuB3q9IwxNcWbGGGxkQ&s", quote: "Fortunately for us, instructors found everything they needed in Cseel. So, we just abandoned the idea of mailing lab kits entirely. Once we subbed in Cseel, everything worked." },
  { name: "Caitlyn Montross", title: "Assistant Professor of Chemistry, Daemen University", image: "https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66fed812d849b3068dc5ec11_Caitlyn-Montross-Daemen-University.avif", quote: "My students are very grade-driven, but I try to get them to be curiosity-driven. One way I do this is by using Cseel as a fun, curious game." },
];

const plans = [
  { name: "Cseel Explorer™", desc: "Start your journey with hands-on learning in a real lab environment — where every experiment fuels curiosity.", price: "₹1,00,000", priceNote: "Per School / Year", subNote: "Based on 40 students, purchased as a 12-month annual term.", features: ["Access to 1000+ experimental modules", "Include Teacher Dashboard", "Basic Analytics", "Email Support"], cta: "Get Started", ctaLink: "/contact-us", popular: false },
  { name: "Cseel Advanced", desc: "Expand your reach with more experiments and flexible student engagement.", price: "Contact sales", features: ["Everything in Cseel Explorer™", "Course Mapping Service", "Dedicated Success Manager", "Priority Support", "Advanced Analytics"], cta: "Contact Sales", ctaLink: "/contact-us", popular: true },
  { name: "Cseel Elite", desc: "Full program support for institutions looking to transform STEM learning.", price: "Contact sales", features: ["Everything in Cseel Advanced", "Custom Content Creation", "Institution-wide Rollout", "LMS Deep Integration", "White-glove Onboarding"], cta: "Contact Sales", ctaLink: "/contact-us", popular: false },
];

const ComparePlans = () => {
  const r1 = useScrollReveal(), r2 = useScrollReveal();
  return (
    <Layout>
      {/* Hero */}
      <section className="hero-gradient py-16">
        <div className="container mx-auto px-4 text-center" style={{ animation: "fadeSlideUp 0.7s ease forwards" }}>
          <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: "hsl(219,72%,47%)" }}>Pricing</p>
          <h1 className="text-3xl md:text-4xl font-bold mb-4" style={{ color: "hsl(214,32%,18%)", letterSpacing: "-0.03em" }}>Choose a Cseel Plan That Fits Your Needs</h1>
          <p className="max-w-xl mx-auto text-sm" style={{ color: "hsl(215,16%,47%)" }}>Trusted by 20,000+ learners and 25+ schools across India.</p>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16" style={{ background: "#fff" }} ref={r1.ref}>
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-12 transition-all duration-700"
            style={{ color: "hsl(214,32%,18%)", letterSpacing: "-0.02em", opacity: r1.visible ? 1 : 0, transform: r1.visible ? "translateY(0)" : "translateY(24px)" }}>
            Customers See the Results with Cseel
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((t, i) => (
              <div
                key={t.name}
                className="bg-white rounded-2xl p-6 hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                style={{ border: "1px solid hsl(214,32%,91%)", opacity: r1.visible ? 1 : 0, transform: r1.visible ? "translateY(0)" : "translateY(36px)", transition: "all 0.6s ease", transitionDelay: `${i * 100}ms` }}
              >
                <img src={t.image} alt={t.name} className="w-14 h-14 rounded-full mb-4 object-cover" />
                <p className="font-semibold text-sm mb-0.5" style={{ color: "hsl(214,32%,18%)" }}>{t.name}</p>
                <p className="text-xs font-medium mb-4" style={{ color: "hsl(219,72%,47%)" }}>{t.title}</p>
                <p className="text-sm italic leading-relaxed" style={{ color: "hsl(215,16%,47%)" }}>"{t.quote}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section className="py-16 hero-gradient" ref={r2.ref}>
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-3 transition-all duration-700"
            style={{ color: "hsl(214,32%,18%)", letterSpacing: "-0.02em", opacity: r2.visible ? 1 : 0, transform: r2.visible ? "translateY(0)" : "translateY(24px)" }}>
            Pricing
          </h2>
          <p className="text-center text-sm mb-12 transition-all duration-700" style={{ color: "hsl(215,16%,47%)", opacity: r2.visible ? 1 : 0, transitionDelay: "100ms" }}>
            Choose a Cseel plan that fits your needs.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {plans.map((plan, i) => (
              <div
                key={plan.name}
                className="relative bg-white rounded-2xl p-8 flex flex-col transition-all duration-700"
                style={{
                  border: plan.popular ? "2px solid hsl(219,72%,47%)" : "1px solid hsl(214,32%,91%)",
                  boxShadow: plan.popular ? "0 8px 32px rgba(26,86,219,0.18)" : "0 2px 8px rgba(0,0,0,0.04)",
                  opacity: r2.visible ? 1 : 0,
                  transform: r2.visible ? "translateY(0)" : "translateY(40px)",
                  transitionDelay: `${i * 100 + 100}ms`,
                }}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-5 py-1 rounded-full text-xs font-bold text-white" style={{ background: "hsl(219,72%,47%)" }}>
                    MOST POPULAR
                  </div>
                )}
                <h3 className="text-lg font-bold mb-2" style={{ color: "hsl(214,32%,18%)" }}>{plan.name}</h3>
                <p className="text-sm leading-relaxed mb-5" style={{ color: "hsl(215,16%,47%)" }}>{plan.desc}</p>
                <div className="mb-1">
                  <span className="text-2xl font-bold" style={{ color: "hsl(214,32%,18%)" }}>{plan.price}</span>
                </div>
                {plan.priceNote && <p className="text-xs mb-1" style={{ color: "hsl(215,16%,60%)" }}>{plan.priceNote}</p>}
                {plan.subNote && <p className="text-xs mb-5" style={{ color: "hsl(215,16%,60%)" }}>{plan.subNote}</p>}

                <div className="flex-1 mt-4 space-y-3">
                  <p className="text-xs font-semibold uppercase tracking-wide mb-3" style={{ color: "hsl(215,16%,47%)" }}>What's included:</p>
                  {plan.features.map((f, fi) => (
                    <div key={fi} className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 mt-0.5 flex-shrink-0" style={{ color: "hsl(219,72%,47%)" }} />
                      <span className="text-sm" style={{ color: "hsl(215,16%,47%)" }}>{f}</span>
                    </div>
                  ))}
                </div>

                <Link
                  to={plan.ctaLink}
                  className="mt-8 block text-center py-3 rounded-full text-sm font-semibold transition-all duration-200 hover:-translate-y-0.5"
                  style={plan.popular
                    ? { background: "hsl(219,72%,47%)", color: "white" }
                    : { border: "2px solid hsl(219,72%,47%)", color: "hsl(219,72%,47%)" }
                  }
                  onMouseEnter={e => { if (plan.popular) (e.currentTarget as HTMLElement).style.background = "hsl(219,72%,38%)"; else (e.currentTarget as HTMLElement).style.background = "hsl(219,72%,95%)"; }}
                  onMouseLeave={e => { if (plan.popular) (e.currentTarget as HTMLElement).style.background = "hsl(219,72%,47%)"; else (e.currentTarget as HTMLElement).style.background = "transparent"; }}
                >
                  {plan.cta}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};
export default ComparePlans;
