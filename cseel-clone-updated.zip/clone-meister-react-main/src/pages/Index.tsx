import Layout from "@/components/Layout";
import { Link } from "react-router-dom";
import { CheckCircle, ArrowRight, ChevronDown } from "lucide-react";
import { useEffect, useRef, useState, useCallback } from "react";

/* ─── Data ─── */
const logoUrls = Array.from({ length: 12 }, (_, i) =>
  `https://www.jigyasu.co.in/assets/images/logo${i + 1}.png`
);

const heroImages = [
  "https://www.thoughtco.com/thmb/kbjOeU1CqYiCzmKIH0FtZ4LrBEQ=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/GettyImages-556450927-58b5b1d95f9b586046b7f7d9.jpg",
  "https://cdn.mos.cms.futurecdn.net/ide7QUU2eMp8ePMs6JAwR6-1200-80.jpg",
  "https://i.pinimg.com/originals/33/2b/3b/332b3b6ee4ff9e2bb34ac529e39ab5ec.jpg",
  "https://www.ase.org.uk/sites/default/files/Spacestation%20by%20S%2BB%20UK.JPG",
];

const catalogItems = [
  { title: "Chemistry", image: "https://img.freepik.com/premium-photo/chemistryfilled-beakers-beakers-with-colorful-chemical-generative-ai_722401-1517.jpg", link: "/demo?search=chemistry" },
  { title: "Biology", image: "https://png.pngtree.com/thumb_back/fw800/background/20241007/pngtree-biology-laboratory-nature-and-science-plants-with-biochemistry-structure-on-green-image_16319180.jpg", link: "/demo?search=biology" },
  { title: "Physics", image: "https://img.freepik.com/premium-photo/physics-lab-background-with-pendulums-circuits_641503-120945.jpg", link: "/demo?search=physics" },
  { title: "Technology", image: "https://img.freepik.com/premium-photo/technology-abstract-circuit-board-texture-background-hightech-futuristic-circuit-board-banner-wallpaper_1029473-136066.jpg", link: "/demo" },
  { title: "Engineering", image: "https://img.freepik.com/premium-photo/engineer-inspects-assembled-products-engineering_697211-20295.jpg", link: "/demo" },
  { title: "Art", image: "https://www.poolewood.co.uk/wp-content/uploads/woodworking-525x311.jpg", link: "/art" },
  { title: "Mathematics", image: "https://wallpaperaccess.com/full/1308246.jpg", link: "/demo" },
];

/* ─── Hooks ─── */
function useScrollReveal(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); obs.unobserve(el); } },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, visible };
}

function useCountUp(target: number, duration = 1800) {
  const [count, setCount] = useState(0);
  const [started, setStarted] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting && !started) { setStarted(true); obs.unobserve(el); } },
      { threshold: 0.5 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [started]);

  useEffect(() => {
    if (!started) return;
    let frame = 0;
    const totalFrames = Math.round(duration / 16);
    const step = () => {
      frame++;
      const progress = frame / totalFrames;
      const eased = 1 - Math.pow(1 - progress, 3); // ease-out cubic
      setCount(Math.round(eased * target));
      if (frame < totalFrames) requestAnimationFrame(step);
      else setCount(target);
    };
    requestAnimationFrame(step);
  }, [started, target, duration]);

  return { count, ref };
}

/* ─── Hero Slider ─── */
function HeroSlider() {
  const [current, setCurrent] = useState(0);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    const t = setInterval(() => setCurrent((p) => (p + 1) % heroImages.length), 4500);
    return () => clearInterval(t);
  }, []);

  return (
    <div>
      {/* Image Slider */}
      <div className="relative max-w-4xl mx-auto rounded-2xl overflow-hidden shadow-2xl" style={{ height: "400px" }}>
        {heroImages.map((src, i) => (
          <div
            key={i}
            className="absolute inset-0 transition-opacity duration-1000"
            style={{ opacity: i === current ? 1 : 0 }}
          >
            <img src={src} alt="CSEEL Lab" className="w-full h-full object-cover" />
          </div>
        ))}
        <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.25) 0%, transparent 50%)" }} />
        {/* Dots */}
        <div className="absolute bottom-4 left-1/2 flex gap-2" style={{ transform: "translateX(-50%)" }}>
          {heroImages.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrent(i)}
              className="transition-all duration-300 rounded-full"
              style={{
                width: i === current ? "24px" : "8px",
                height: "8px",
                background: i === current ? "white" : "rgba(255,255,255,0.5)",
              }}
            />
          ))}
        </div>
      </div>

      {/* Expandable text block - matches cseel.org "Read More" */}
      <div className="max-w-3xl mx-auto mt-8 text-center">
        <div
          className="overflow-hidden transition-all duration-500"
          style={{ maxHeight: expanded ? "300px" : "0px" }}
        >
          <p className="text-sm leading-relaxed pb-4" style={{ color: "hsl(215,16%,47%)" }}>
            Through <strong style={{ color: "hsl(214,32%,18%)" }}>experiential learning</strong> and{" "}
            <strong style={{ color: "hsl(214,32%,18%)" }}>hands on learning</strong>, students discover how things work and why they work, building strong conceptual understanding and a deep connection with the world around them. This approach strongly aligns with <strong style={{ color: "hsl(214,32%,18%)" }}>NEP 2020's</strong> emphasis on <strong style={{ color: "hsl(214,32%,18%)" }}>learning by doing</strong>, <strong style={{ color: "hsl(214,32%,18%)" }}>learner-centred pedagogy</strong>, <strong style={{ color: "hsl(214,32%,18%)" }}>development of scientific temper</strong>, and <strong style={{ color: "hsl(214,32%,18%)" }}>real-life application of knowledge</strong>, ensuring that learning is meaningful, engaging, and future-ready.
          </p>
        </div>
        <button
          onClick={() => setExpanded(!expanded)}
          className="text-sm font-semibold flex items-center gap-1 mx-auto transition-colors hover:opacity-80"
          style={{ color: "hsl(219,72%,47%)" }}
        >
          {expanded ? "Read Less" : "Read More"}
          <ChevronDown
            className="h-4 w-4 transition-transform duration-300"
            style={{ transform: expanded ? "rotate(180deg)" : "rotate(0deg)" }}
          />
        </button>
      </div>
    </div>
  );
}

/* ─── Stat Card ─── */
function StatCard({ value, suffix = "%", label, desc, delay = 0 }: {
  value?: number; suffix?: string; label: string; desc: string; delay?: number; customValue?: string;
}) {
  const { count, ref: countRef } = useCountUp(value ?? 0);
  const { ref, visible } = useScrollReveal(0.3);

  return (
    <div
      ref={ref}
      className="p-8 rounded-2xl transition-all duration-700 card-hover"
      style={{
        background: "hsl(219,72%,96%)",
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(40px)",
        transitionDelay: `${delay}ms`,
      }}
    >
      <div
        ref={countRef}
        className="text-5xl font-bold mb-3 stat-number"
        style={{ color: "hsl(219,72%,47%)" }}
      >
        {value !== undefined ? `+${count}${suffix}` : "≧ C"}
      </div>
      <h3 className="text-base font-semibold mb-2" style={{ color: "hsl(214,32%,18%)" }}>{label}</h3>
      <p className="text-sm leading-relaxed" style={{ color: "hsl(215,16%,47%)" }}>{desc}</p>
    </div>
  );
}

/* ─── Feature Section Row ─── */
function FeatureRow({ tag, title, desc, checks, sources, imgSrc, imgAlt, reverse = false, delay = 0 }: {
  tag: string; title: string; desc: string;
  checks: { title: string; body: string; source?: string }[];
  sources?: string;
  imgSrc: string; imgAlt: string; reverse?: boolean; delay?: number;
}) {
  const { ref, visible } = useScrollReveal();
  return (
    <div
      ref={ref}
      className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center transition-all duration-700"
      style={{ opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(48px)", transitionDelay: `${delay}ms` }}
    >
      <div className={reverse ? "lg:order-2" : ""}>
        <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: "hsl(219,72%,47%)" }}>{tag}</p>
        <h2 className="text-2xl md:text-3xl font-bold mb-4" style={{ color: "hsl(214,32%,18%)", letterSpacing: "-0.02em" }}>{title}</h2>
        <p className="text-sm leading-relaxed mb-6" style={{ color: "hsl(215,16%,47%)" }}>{desc}</p>
        <div className="space-y-5">
          {checks.map((c, i) => (
            <div key={i} className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 mt-0.5 flex-shrink-0" style={{ color: "hsl(219,72%,47%)" }} />
              <div>
                <p className="text-sm font-semibold mb-1" style={{ color: "hsl(214,32%,18%)" }}>{c.title}</p>
                <p className="text-sm leading-relaxed" style={{ color: "hsl(215,16%,47%)" }}>{c.body}</p>
              </div>
            </div>
          ))}
        </div>
        {sources && (
          <p className="text-xs mt-6" style={{ color: "hsl(215,16%,65%)" }}>
            <span className="font-medium">Sources:</span> {sources}
          </p>
        )}
      </div>
      <div className={`rounded-2xl overflow-hidden shadow-lg img-zoom ${reverse ? "lg:order-1" : ""}`}>
        <img src={imgSrc} alt={imgAlt} className="w-full h-80 object-cover" />
      </div>
    </div>
  );
}

/* ─── Catalog Card ─── */
function CatalogCard({ item, delay }: { item: typeof catalogItems[0]; delay: number }) {
  const { ref, visible } = useScrollReveal(0.1);
  return (
    <div
      ref={ref}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0) scale(1)" : "translateY(20px) scale(0.94)",
        transition: "all 0.5s ease",
        transitionDelay: `${delay}ms`,
      }}
    >
      <Link
        to={item.link}
        className="group block relative rounded-2xl overflow-hidden shadow-md aspect-square"
        style={{ transition: "transform 0.25s ease, box-shadow 0.25s ease" }}
        onMouseEnter={e => { (e.currentTarget as HTMLElement).style.transform = "translateY(-4px)"; (e.currentTarget as HTMLElement).style.boxShadow = "0 16px 40px rgba(26,86,219,0.18)"; }}
        onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = "translateY(0)"; (e.currentTarget as HTMLElement).style.boxShadow = ""; }}
      >
        <img src={item.image} alt={item.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
        <div className="absolute inset-0 flex flex-col justify-end p-3" style={{ background: "linear-gradient(to top, rgba(0,0,0,0.75) 0%, transparent 60%)" }}>
          <h3 className="text-white font-semibold text-sm mb-1">{item.title}</h3>
          <p className="text-white/0 group-hover:text-white/80 text-xs transition-all duration-300">View Demo →</p>
        </div>
      </Link>
    </div>
  );
}

/* ─── Main Page ─── */
const Index = () => {
  const logosReveal = useScrollReveal(0.05);
  const metricsReveal = useScrollReveal(0.2);
  const awardsReveal = useScrollReveal(0.15);
  const ctaReveal = useScrollReveal(0.2);
  const easyReveal = useScrollReveal(0.1);

  return (
    <Layout>

      {/* ════ HERO ════ */}
      <section className="hero-gradient py-16 md:py-20 overflow-hidden">
        <div className="container mx-auto px-4 text-center">
          <h1
            className="font-bold mb-4"
            style={{
              fontSize: "clamp(2rem, 4vw, 3.5rem)",
              letterSpacing: "-0.03em",
              color: "hsl(214,32%,18%)",
              animation: "fadeSlideUp 0.7s ease forwards",
            }}
          >
            Welcome to{" "}
            <span style={{ color: "hsl(219,72%,47%)" }}>C.S.E.E.L</span>
            <br />
            <span className="font-normal text-xl md:text-2xl" style={{ color: "hsl(219,72%,47%)", letterSpacing: "0" }}>
              Center for Scientific Exploration and Experiential Learning
            </span>
          </h1>

          <div style={{ animation: "fadeSlideUp 0.7s ease 0.15s both" }} className="max-w-3xl mx-auto mb-3">
            <p className="text-sm md:text-base leading-relaxed" style={{ color: "hsl(215,16%,47%)" }}>
              At CSEEL, we share the vision of the National Education Policy (<strong style={{ color: "hsl(214,32%,18%)" }}>NEP</strong>) 2020 to transform Indian education from{" "}
              <strong style={{ color: "hsl(214,32%,18%)" }}>rote memorization</strong> to{" "}
              <strong style={{ color: "hsl(214,32%,18%)" }}>experiential, inquiry-based, competency-focused</strong>, and{" "}
              <strong style={{ color: "hsl(214,32%,18%)" }}>hands-on</strong> learning.
            </p>
          </div>

          <p
            className="text-sm mb-6 max-w-2xl mx-auto"
            style={{ color: "hsl(215,16%,47%)", animation: "fadeSlideUp 0.7s ease 0.3s both" }}
          >
            At CSEEL, we believe the best way to learn science is by doing it. Students learn science most effectively when they{" "}
            <strong style={{ color: "hsl(214,32%,18%)" }}>observe</strong>,{" "}
            <strong style={{ color: "hsl(214,32%,18%)" }}>experiment</strong>,{" "}
            <strong style={{ color: "hsl(214,32%,18%)" }}>analyse</strong>,{" "}
            <strong style={{ color: "hsl(214,32%,18%)" }}>build</strong>, and{" "}
            <strong style={{ color: "hsl(214,32%,18%)" }}>solve real-world problems</strong>, rather than only reading from textbooks.
          </p>

          {/* Buttons */}
          <div
            className="flex flex-wrap justify-center gap-4 mb-10"
            style={{ animation: "fadeSlideUp 0.7s ease 0.45s both" }}
          >
            <Link
              to="/compare-plans"
              className="px-8 py-3 rounded-full text-sm font-semibold text-white transition-all duration-200 hover:shadow-xl hover:-translate-y-0.5 flex items-center gap-2"
              style={{ background: "hsl(219,72%,47%)" }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "hsl(219,72%,38%)"; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "hsl(219,72%,47%)"; }}
            >
              Our Plans <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="/simulations"
              className="px-8 py-3 rounded-full text-sm font-semibold transition-all duration-200 hover:shadow-md hover:-translate-y-0.5"
              style={{ border: "2px solid hsl(219,72%,47%)", color: "hsl(219,72%,47%)", background: "transparent" }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "hsl(219,72%,95%)"; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; }}
            >
              Live Lab Tour
            </Link>
          </div>

          {/* Hero Slider */}
          <div style={{ animation: "fadeSlideUp 0.8s ease 0.6s both" }}>
            <HeroSlider />
          </div>
        </div>
      </section>

      {/* ════ STATS ════ */}
      <section className="py-16" style={{ background: "#fff" }}>
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <StatCard value={42} label="Higher Retention Rate" desc="Students who are actively engaged in hands-on STEAM/STEM learning show up to 42% higher knowledge retention compared to traditional lecture-based learning." delay={0} />
            <StatCard value={25} label="Engagement" desc="Gamified, interactive STEAM environments increase student engagement and motivation by 25%, making learning enjoyable and effective." delay={120} />
            <StatCard
              label="Higher Academic Success"
              desc="Students earning a grade of C or higher in foundational science courses are significantly more likely to persist and succeed in STEAM careers."
              delay={240}
            />
          </div>
          <p className="text-xs mt-6 text-center" style={{ color: "hsl(215,16%,60%)" }}>
            Sources: 1. Florida International University Gateway Project &bull; 2. A Playful Game-Changer (Krause et al, 2015) &bull; 3. Reducing Achievement Gaps in Undergraduate General Chemistry (Harris, et al, 2020)
          </p>
        </div>
      </section>

      {/* ════ LOGOS ════ */}
      <section className="py-14" style={{ background: "#fff" }} ref={logosReveal.ref}>
        <div className="container mx-auto px-4 text-center mb-8">
          <h2
            className="text-2xl md:text-3xl font-bold transition-all duration-700"
            style={{
              color: "hsl(214,32%,18%)",
              letterSpacing: "-0.02em",
              opacity: logosReveal.visible ? 1 : 0,
              transform: logosReveal.visible ? "translateY(0)" : "translateY(24px)",
            }}
          >
            CSEEL Powers Opportunity Through STEAM.
          </h2>
          <Link
            to="/simulations"
            className="inline-flex items-center gap-1 mt-3 text-sm font-semibold transition-all duration-700 hover:gap-2"
            style={{
              color: "hsl(219,72%,47%)",
              opacity: logosReveal.visible ? 1 : 0,
              transitionDelay: "150ms",
            }}
          >
            See How It Works <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="overflow-hidden py-6 relative">
          {/* Fade edges */}
          <div className="absolute left-0 top-0 h-full w-24 z-10 pointer-events-none" style={{ background: "linear-gradient(to right, white 0%, transparent 100%)" }} />
          <div className="absolute right-0 top-0 h-full w-24 z-10 pointer-events-none" style={{ background: "linear-gradient(to left, white 0%, transparent 100%)" }} />
          <div className="animate-scroll-logos flex" style={{ width: "max-content" }}>
            {[...logoUrls, ...logoUrls, ...logoUrls].map((url, i) => (
              <img
                key={i}
                src={url}
                alt="Partner logo"
                className="h-10 mx-10 object-contain transition-opacity duration-300"
                style={{ opacity: 0.45, filter: "grayscale(30%)" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.opacity = "1"; (e.currentTarget as HTMLElement).style.filter = "grayscale(0%)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.opacity = "0.45"; (e.currentTarget as HTMLElement).style.filter = "grayscale(30%)"; }}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ════ KEY METRICS ════ */}
      <section className="py-16 hero-gradient" ref={metricsReveal.ref}>
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            {[
              { num: "20,000+", label: "Active\nLearner" },
              { num: "1000+", label: "Concept\nBased Experiments" },
              { num: "25+", label: "Schools\nEmpowered" },
            ].map((m, i) => (
              <div
                key={i}
                style={{
                  opacity: metricsReveal.visible ? 1 : 0,
                  transform: metricsReveal.visible ? "translateY(0)" : "translateY(32px)",
                  transition: "all 0.65s ease",
                  transitionDelay: `${i * 130}ms`,
                }}
              >
                <div className="text-5xl md:text-6xl font-bold mb-2 stat-number" style={{ color: "hsl(219,72%,47%)", letterSpacing: "-0.03em" }}>
                  {m.num}
                </div>
                <p className="text-sm font-semibold whitespace-pre-line" style={{ color: "hsl(214,32%,18%)" }}>{m.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ════ INSTITUTIONS SECTION ════ */}
      <section className="py-16" style={{ background: "#fff" }}>
        <div className="container mx-auto px-4">
          <div
            className="text-center mb-14"
            style={{ opacity: 1 }}
          >
            <h2 className="text-2xl md:text-3xl font-bold mb-1" style={{ color: "hsl(214,32%,18%)", letterSpacing: "-0.02em" }}>
              Institutions Use Cseel to Remove Roadblocks for Faculty
            </h2>
          </div>

          <div className="space-y-20">
            <FeatureRow
              tag="No need for extra grading or planning time"
              title="Students look forward to learning at their own pace"
              desc="Educators assign CSEEL experimental labs to actively engage students—without increasing their already busy workloads. Higher engagement naturally leads to better understanding, improved grades, and stronger retention."
              checks={[
                { title: "C- to B+ Grade Improvement", body: "CSEEL helps students improve their academic performance by an average of one full letter grade or more." },
                { title: "82% Student Engagement", body: "82% of students using CSEEL report high levels of engagement, participation, and interest in learning." },
              ]}
              sources="4. Evidence that Labster Boosts Student Success (Labster, 2024)  •  5. Exploring Nationwide Student Engagement (Schecter, et al, 2024)"
              imgSrc="https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66bf9f93d712be6d135ac575_Student-Remote-Room-Labster-reverse-edit.avif"
              imgAlt="Woman sitting at a desk with a laptop"
            />
            <FeatureRow
              tag="Higher Pass Rates. Stronger Retention."
              title="Improved Student Success"
              desc="CSEEL has been proven to increase student grades, pass rates, and overall academic performance. Strong outcomes in early gateway science courses significantly improve the likelihood of students continuing in STEM pathways."
              checks={[
                { title: "34% Reduction in DFW Rates", body: "Institutions using CSEEL have observed a 34% decrease in DFW (Drop–Fail–Withdraw) rates across multiple semesters and courses." },
                { title: "93% Positive Student Experience", body: "93% of students report a positive learning experience with CSEEL, highlighting increased engagement, confidence, and satisfaction." },
              ]}
              sources="6. Virtual Lab Implementation Model Predicts STEM Future Plans (Schecter et al, 2023)  •  7. NPS score, internal company data"
              imgSrc="https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66bf944f3df098f183b92727_Lab-Scientists-Beakers-edit.avif"
              imgAlt="Female and male scientists looking at a beaker"
              reverse
              delay={100}
            />
            <FeatureRow
              tag="Increase Access"
              title="Dismantle Barriers to Achievement"
              desc="Expand STEM equity and access among your students. Cseel is designed to meet diverse student needs and offer a more consistent, accessible science learning experience."
              checks={[
                { title: "24% Learning Gains for Struggling Students", body: "The lowest-performing students using CSEEL show an average 24% improvement in pre-to-post test knowledge, helping close achievement gaps." },
                { title: "Trusted by Educators", body: "9 out of 10 educators say they would recommend CSEEL to other teachers or institutions, reflecting strong confidence in its impact." },
              ]}
              sources="8. Makransky, et al, 2016  •  9. Labster Customer Survey 2023"
              imgSrc="https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66be608d71d32863b2bf5487_Students-Desk-Classroom-Laptop-reverse.avif"
              imgAlt="Students sitting in a classroom and smiling"
              delay={100}
            />
          </div>
        </div>
      </section>

      {/* ════ CATALOG ════ */}
      <section className="py-16 hero-gradient">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-10" style={{ color: "hsl(214,32%,18%)", letterSpacing: "-0.02em" }}>
            Explore the Cseel Catalog
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-4 mb-8">
            {catalogItems.map((item, i) => (
              <CatalogCard key={item.title} item={item} delay={i * 55} />
            ))}
          </div>

          {/* View Full Library Card */}
          <div className="mt-6 text-center">
            <Link
              to="/simulations"
              className="inline-flex flex-col items-center justify-center px-10 py-6 rounded-2xl text-white transition-all duration-200 hover:-translate-y-1 hover:shadow-xl"
              style={{ background: "hsl(219,72%,47%)" }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "hsl(219,72%,38%)"; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "hsl(219,72%,47%)"; }}
            >
              <span className="font-bold text-lg mb-2">View the Full Experimental Library</span>
              <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 text-white/80 text-xs">
                <span>✓ 1000+ immersive Experiments</span>
                <span>✓ Automated grading</span>
                <span>✓ Unlimited play attempts</span>
                <span>✓ Quiz customization</span>
                <span>✓ Accessibility features</span>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* ════ TESTIMONIAL ════ */}
      <TestimonialSection />

      {/* ════ AWARDS ════ */}
      <section className="py-16 hero-gradient" ref={awardsReveal.ref}>
        <div className="container mx-auto px-4">
          <div
            className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center transition-all duration-700"
            style={{ opacity: awardsReveal.visible ? 1 : 0, transform: awardsReveal.visible ? "translateY(0)" : "translateY(36px)" }}
          >
            <div className="flex flex-wrap gap-6 justify-center lg:justify-start">
              {[
                "https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66b6088ed6f732140b977d32_gsv.avif",
                "https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66b6088eb79f5af91f5f4c8e_promise.avif",
                "https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66b6088e74ca012dd9db92f8_edtech.avif",
                "https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66b6088eb05eb79120a532a2_advocate.avif",
                "https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66b6088e98414361f6b7c4e3_leader.avif",
                "https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66b6088e39ada1f2e6d15101_ability.avif",
              ].map((src, i) => (
                <img
                  key={i}
                  src={src}
                  alt="Award badge"
                  className="h-20 w-20 object-contain transition-all duration-300 hover:scale-110"
                  style={{
                    opacity: awardsReveal.visible ? 1 : 0,
                    transform: awardsReveal.visible ? "scale(1)" : "scale(0.7)",
                    transition: "all 0.5s ease",
                    transitionDelay: `${i * 80}ms`,
                  }}
                />
              ))}
            </div>
            <div>
              <h2 className="text-2xl md:text-3xl font-bold mb-4" style={{ color: "hsl(214,32%,18%)", letterSpacing: "-0.02em" }}>
                Award-Winning Learning Platform
              </h2>
              <p className="text-sm leading-relaxed mb-6" style={{ color: "hsl(215,16%,47%)" }}>
                Cseel has earned recognition for our research-based learning architecture, best-in-class customer support, and student impact. Learn why our virtual lab simulations have received more than 10 prestigious education awards.
              </p>
              <Link
                to="/about-us"
                className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full text-sm font-semibold text-white transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg"
                style={{ background: "hsl(219,72%,47%)" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "hsl(219,72%,38%)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "hsl(219,72%,47%)"; }}
              >
                Learn More About Cseel <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ════ EASY TO USE ════ */}
      <section className="py-16" style={{ background: "#fff" }} ref={easyReveal.ref}>
        <div className="container mx-auto px-4">
          <h2
            className="text-2xl md:text-3xl font-bold text-center mb-12 transition-all duration-700"
            style={{
              color: "hsl(214,32%,18%)",
              letterSpacing: "-0.02em",
              opacity: easyReveal.visible ? 1 : 0,
              transform: easyReveal.visible ? "translateY(0)" : "translateY(24px)",
            }}
          >
            We Make it Easy to Use Cseel in STEM Courses
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { tag: "LMS Integration", title: "Stay with your LMS or use our Course Manager", desc: "Assign CSEEL right from your LMS! Explore and select content, and monitor student results, all without having to leave your course page." },
              { tag: "Course Mapping", title: "Easily match Cseel to your curriculum", desc: "Browse our Catalog to find virtual labs that match your curriculum, or get our course mapping service with Advanced or Elite plans." },
              { tag: "Technical Support", title: "Get live support whenever you need it", desc: "Our award-winning support team is ready to help you and your students at every step via Live Chat, Help Center, and training guides." },
            ].map((c, i) => (
              <div
                key={i}
                className="p-8 rounded-2xl card-hover"
                style={{
                  border: "1px solid hsl(214,32%,91%)",
                  opacity: easyReveal.visible ? 1 : 0,
                  transform: easyReveal.visible ? "translateY(0)" : "translateY(40px)",
                  transition: "opacity 0.6s ease, transform 0.6s ease, box-shadow 0.25s ease",
                  transitionDelay: `${i * 110}ms`,
                }}
              >
                <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: "hsl(219,72%,47%)" }}>{c.tag}</p>
                <h3 className="text-base font-bold mb-3" style={{ color: "hsl(214,32%,18%)" }}>{c.title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: "hsl(215,16%,47%)" }}>{c.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ════ FINAL CTA ════ */}
      <section className="py-16 hero-gradient" ref={ctaReveal.ref}>
        <div className="container mx-auto px-4">
          <div
            className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center transition-all duration-700"
            style={{ opacity: ctaReveal.visible ? 1 : 0, transform: ctaReveal.visible ? "translateY(0)" : "translateY(36px)" }}
            ref={ctaReveal.ref}
          >
            <div>
              <h2 className="text-2xl md:text-3xl font-bold mb-4" style={{ color: "hsl(214,32%,18%)", letterSpacing: "-0.02em" }}>
                Find the Plan That Works For You
              </h2>
              <p className="text-sm leading-relaxed mb-6" style={{ color: "hsl(215,16%,47%)" }}>
                See our plan options, learn more about virtual labs, and find out how easy it is to get started with Cseel.
              </p>
              <Link
                to="/compare-plans"
                className="inline-flex items-center gap-2 px-8 py-3 rounded-full text-sm font-semibold text-white transition-all duration-200 hover:-translate-y-0.5 hover:shadow-xl"
                style={{ background: "hsl(219,72%,47%)" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "hsl(219,72%,38%)"; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "hsl(219,72%,47%)"; }}
              >
                Compare Plans <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
            <div className="rounded-2xl overflow-hidden shadow-lg img-zoom">
              <img
                src="https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66c366924698e845aff6397c_Group-Laptop-Labster-edit-2.avif"
                alt="Students with laptop"
                className="w-full h-80 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

    </Layout>
  );
};

/* ─── Testimonial Section ─── */
function TestimonialSection() {
  const { ref, visible } = useScrollReveal();
  return (
    <section className="py-16" style={{ background: "#fff" }}>
      <div className="container mx-auto px-4">
        <div
          ref={ref}
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center transition-all duration-700"
          style={{ opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(40px)" }}
        >
          <div>
            <div className="text-7xl font-bold mb-2 leading-none" style={{ color: "hsl(219,72%,80%)", fontFamily: "Georgia, serif" }}>"</div>
            <blockquote className="text-xl md:text-2xl font-medium italic leading-relaxed -mt-6" style={{ color: "hsl(214,32%,18%)" }}>
              Cseel emphasizes the theory behind the labs. It is easier for students to carry that knowledge forward so that they don't find themselves in an advanced class when they missed some basic concepts in their gateway class.
            </blockquote>
            <p className="mt-5 text-sm" style={{ color: "hsl(215,16%,47%)" }}>Delhi, India</p>
            <p className="font-semibold text-sm" style={{ color: "hsl(214,32%,18%)" }}>Sunil Lakra, DAV School</p>
          </div>
          <div className="rounded-2xl overflow-hidden shadow-lg img-zoom">
            <img
              src="https://davcsp.org/File/50/Slider_40e21c0d-d24b-42cf-9023-30a8c9ca0712_davcamp-1.jpeg"
              alt="Three science students in a lab"
              className="w-full h-80 object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

export default Index;
