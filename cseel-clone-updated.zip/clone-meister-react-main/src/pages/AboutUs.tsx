import Layout from "@/components/Layout";
import { Link } from "react-router-dom";
import { useEffect, useRef, useState } from "react";

function useScrollReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setVisible(true); obs.unobserve(el); } }, { threshold: 0.12 });
    obs.observe(el); return () => obs.disconnect();
  }, []);
  return { ref, visible };
}

const teamMembers = [
  { name: "Catherine Gasse", title: "Chief People Officer", image: "https://cdn.prod.website-files.com/6320bb946c79f421bd3b702f/67d09c375fc0591b6041a3ef_About%20Us-Headshot-07.png", bio: "Catherine's leadership centers on empowering others to do their best work, creating an environment where talent can flourish and innovation can take root." },
  { name: "Bjørn Toft Madsen", title: "Chief Product & Technology Officer", image: "https://cdn.prod.website-files.com/6320bb946c79f421bd3b702f/676da6f6eebf5298444b9584_About%20Us-Headshot-06.png", bio: "Bjorn oversees Product Management and Software Engineering teams. He was instrumental in three Xbox hardware launches." },
];

const AboutUs = () => {
  const r1 = useScrollReveal(), r2 = useScrollReveal(), r3 = useScrollReveal(), r4 = useScrollReveal();
  return (
    <Layout>
      {/* Hero */}
      <section className="about-hero-gradient py-20">
        <div className="container mx-auto px-4 text-center" style={{ animation: "fadeSlideUp 0.7s ease forwards" }}>
          <p className="text-sm font-semibold uppercase tracking-widest mb-3" style={{ color: "rgba(255,255,255,0.65)" }}>Our Mission</p>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6" style={{ letterSpacing: "-0.03em" }}>About CSEEL</h1>
          <p className="max-w-3xl mx-auto text-sm md:text-base leading-relaxed" style={{ color: "rgba(255,255,255,0.82)" }}>
            CSEEL (Center for Scientific Exploration & Experimental Learning) is a visionary initiative dedicated to revolutionizing science education in India. Our mission is to bridge the gap between theoretical knowledge and practical understanding through immersive, hands-on, and inquiry-based learning experiences.
          </p>
        </div>
      </section>

      {/* Purpose */}
      <section className="py-16" style={{ background: "#fff" }}>
        <div className="container mx-auto px-4">
          <div
            ref={r1.ref}
            className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center transition-all duration-700"
            style={{ opacity: r1.visible ? 1 : 0, transform: r1.visible ? "translateY(0)" : "translateY(40px)" }}
          >
            <div>
              <p className="text-xs font-semibold uppercase tracking-widest mb-3" style={{ color: "hsl(219,72%,47%)" }}>Who We Are</p>
              <h2 className="text-2xl md:text-3xl font-bold mb-4" style={{ color: "hsl(219,72%,47%)", letterSpacing: "-0.02em" }}>Our Purpose</h2>
              <p className="text-sm leading-relaxed mb-4" style={{ color: "hsl(215,16%,47%)" }}>
                CSEEL creates a dynamic and safe space where students can carry out real experiments, work with scientific equipment, and explore complex STEM concepts through practical application. Our goal is to replace passive learning with active scientific discovery.
              </p>
              <p className="text-sm leading-relaxed" style={{ color: "hsl(215,16%,47%)" }}>
                Unlike virtual labs, CSEEL is fully physical—students touch, test, build, and innovate using real materials. This makes learning more meaningful, especially in fields that demand tactile understanding and precision.
              </p>
            </div>
            <div className="rounded-2xl overflow-hidden shadow-lg" style={{ overflow: "hidden" }}>
              <img src="https://cdn.prod.website-files.com/63105b5082760e06eb992f00/66bf9f93d712be6d135ac575_Student-Remote-Room-Labster-reverse-edit.avif" alt="Students learning" className="w-full h-80 object-cover transition-transform duration-500 hover:scale-105" />
            </div>
          </div>
        </div>
      </section>

      {/* Approach */}
      <section className="py-16 hero-gradient" ref={r2.ref}>
        <div className="container mx-auto px-4">
          <h2
            className="text-2xl md:text-3xl font-bold text-center mb-12 transition-all duration-700"
            style={{ color: "hsl(214,32%,18%)", letterSpacing: "-0.02em", opacity: r2.visible ? 1 : 0, transform: r2.visible ? "translateY(0)" : "translateY(24px)" }}
          >
            Our Approach
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { title: "Experiential Learning", desc: "Students learn by doing — observing, experimenting, analyzing, and solving real-world problems." },
              { title: "NEP 2020 Aligned", desc: "Aligned with India's National Education Policy focusing on learner-centred pedagogy and scientific temper." },
              { title: "Hands-on Labs", desc: "Physical labs with real equipment that let students touch, test, build, and innovate." },
            ].map((c, i) => (
              <div
                key={i}
                className="bg-white p-8 rounded-2xl shadow-sm transition-all duration-700 hover:shadow-md hover:-translate-y-1"
                style={{ opacity: r2.visible ? 1 : 0, transform: r2.visible ? "translateY(0)" : "translateY(36px)", transitionDelay: `${i * 100}ms` }}
              >
                <h3 className="text-base font-bold mb-3" style={{ color: "hsl(219,72%,47%)" }}>{c.title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: "hsl(215,16%,47%)" }}>{c.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-16" style={{ background: "#fff" }} ref={r3.ref}>
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-12 transition-all duration-700"
            style={{ color: "hsl(214,32%,18%)", letterSpacing: "-0.02em", opacity: r3.visible ? 1 : 0, transform: r3.visible ? "translateY(0)" : "translateY(24px)" }}>
            Our Team
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto">
            {teamMembers.map((m, i) => (
              <div
                key={m.name}
                className="bg-white rounded-2xl p-6 text-center hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                style={{ border: "1px solid hsl(214,32%,91%)", opacity: r3.visible ? 1 : 0, transform: r3.visible ? "translateY(0)" : "translateY(36px)", transition: "all 0.6s ease", transitionDelay: `${i * 120}ms` }}
              >
                <img src={m.image} alt={m.name} className="w-28 h-28 rounded-full mx-auto mb-4 object-cover" />
                <h3 className="text-base font-bold mb-1" style={{ color: "hsl(214,32%,18%)" }}>{m.name}</h3>
                <p className="text-sm font-medium mb-3" style={{ color: "hsl(219,72%,47%)" }}>{m.title}</p>
                <p className="text-sm leading-relaxed" style={{ color: "hsl(215,16%,47%)" }}>{m.bio}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 about-hero-gradient" ref={r4.ref}>
        <div
          className="container mx-auto px-4 text-center transition-all duration-700"
          style={{ opacity: r4.visible ? 1 : 0, transform: r4.visible ? "translateY(0)" : "translateY(36px)" }}
        >
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4" style={{ letterSpacing: "-0.02em" }}>Ready to Transform Learning?</h2>
          <p className="mb-8 text-sm" style={{ color: "rgba(255,255,255,0.75)" }}>
            Discover how CSEEL can help your institution deliver impactful science education.
          </p>
          <Link to="/compare-plans" className="inline-flex items-center px-8 py-3 bg-white rounded-full text-sm font-semibold transition-all duration-200 hover:shadow-xl hover:-translate-y-0.5" style={{ color: "hsl(219,72%,47%)" }}>
            Compare Plans
          </Link>
        </div>
      </section>
    </Layout>
  );
};
export default AboutUs;
