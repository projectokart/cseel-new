import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import AboutUs from "./pages/AboutUs.tsx";
import ComparePlans from "./pages/ComparePlans.tsx";
import Simulations from "./pages/Simulations.tsx";
import ContactUs from "./pages/ContactUs.tsx";
import Demo from "./pages/Demo.tsx";
import Art from "./pages/Art.tsx";
import Login from "./pages/Login.tsx";
import NotFound from "./pages/NotFound.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/about-us" element={<AboutUs />} />
          <Route path="/compare-plans" element={<ComparePlans />} />
          <Route path="/simulations" element={<Simulations />} />
          <Route path="/contact-us" element={<ContactUs />} />
          <Route path="/demo" element={<Demo />} />
          <Route path="/art" element={<Art />} />
          <Route path="/login" element={<Login />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
